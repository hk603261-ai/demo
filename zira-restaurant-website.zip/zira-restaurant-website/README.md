# ZIRA Restaurant — Website Concept

A presentation-ready, responsive HTML/CSS/JS website concept for Zira Restaurant in Dubai.

## Included
- `index.html` — main website
- `assets/style.css` — design system + responsive layout
- `assets/script.js` — mobile nav + dynamic year

## Verified public business details used in the concept
- Name: Zira Restaurant
- Cuisine: Uzbek, Russian, Turkish
- Address: Dubai Abdullah Omran Taryam Street 171 Office Park Block B, Dubai, UAE
- Phone: +971 4 589 1239
- Public listing rating: 4.8/5 (1,383 reviews at time of research)
- Hours: daily 10:00 AM–11:00 PM
- Typical spend: AED 50–100 per person

## Important before pitching / launching
This is a prototype, not an official Zira Restaurant website. Public listings should be re-checked with the business before launch. Some public search results also show a separate site at `zirarestaurant.shop`; confirm whether that site is official/owned by the restaurant before representing your prototype as a replacement.

### Photography
The prototype references public image URLs from Zomato and zirarestaurant.shop so the ZIP stays lightweight. Before commercial launch, replace them with photographs that the restaurant explicitly authorizes you to use.

## Open locally
Double-click `index.html` or serve the folder with any static web server.
