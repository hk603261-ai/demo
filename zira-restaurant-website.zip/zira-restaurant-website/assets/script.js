const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
if (toggle) {
  toggle.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', String(!open));
    nav.style.display = open ? '' : 'flex';
    nav.style.position = 'absolute';
    nav.style.top = '72px';
    nav.style.left = '0';
    nav.style.right = '0';
    nav.style.background = '#0b1712';
    nav.style.padding = '18px 20px 22px';
    nav.style.flexDirection = 'column';
    nav.style.gap = '14px';
    nav.style.borderBottom = '1px solid rgba(255,255,255,.12)';
  });
}
document.querySelectorAll('.nav a').forEach(a => a.addEventListener('click', () => {
  if (window.innerWidth <= 620 && toggle) {
    toggle.setAttribute('aria-expanded', 'false');
    nav.style.display = 'none';
  }
}));
document.getElementById('year').textContent = new Date().getFullYear();
